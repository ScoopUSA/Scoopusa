#!/bin/bash -e

chmod 700 ~/.ssh

exec "$@"