
// AdminDashboard.js
import { useEffect, useState } from "react";
import { collection, getDocs, updateDoc, doc } from "firebase/firestore";
import { db } from "./App";
import { sendEmailNotification } from "./notifications";

export default function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      const usersSnapshot = await getDocs(collection(db, "users"));
      const usersData = usersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      for (const user of usersData) {
        if (
          user.role === "driver" &&
          user.tripsCompleted >= 50 &&
          !user.bonusPaid
        ) {
          await updateDoc(doc(db, "users", user.id), { bonusPaid: true });
          await sendEmailNotification(user.email, "🎉 Scoop USA Bonus Paid!", { name: user.name });
        }
      }

      const refreshedSnapshot = await getDocs(collection(db, "users"));
      const refreshedData = refreshedSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setUsers(refreshedData);
      setLoading(false);
    };
    fetchUsers();
  }, []);

  const driverCount = users.filter(user => user.role === "driver").length;
  const riderCount = users.filter(user => user.role === "rider").length;
  const paidDrivers = users.filter(user => user.role === "driver" && user.bonusPaid).length;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      {loading ? (
        <p>Loading user data...</p>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 border rounded shadow">
              <h2 className="text-lg font-semibold">Total Drivers</h2>
              <p className="text-2xl">{driverCount}</p>
            </div>
            <div className="p-4 border rounded shadow">
              <h2 className="text-lg font-semibold">Total Riders</h2>
              <p className="text-2xl">{riderCount}</p>
            </div>
          </div>
          <div className="p-4 border rounded shadow">
            <h2 className="text-lg font-semibold">Drivers Paid Bonuses</h2>
            <p className="text-xl">{paidDrivers} / 1000</p>
          </div>
          <div className="p-4 border rounded shadow overflow-auto">
            <h2 className="text-lg font-semibold mb-2">All Users</h2>
            <table className="min-w-full text-sm">
              <thead>
                <tr>
                  <th className="text-left px-2 py-1">Name</th>
                  <th className="text-left px-2 py-1">Email</th>
                  <th className="text-left px-2 py-1">Role</th>
                  <th className="text-left px-2 py-1">Trips</th>
                  <th className="text-left px-2 py-1">Bonus Paid</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id} className="border-t">
                    <td className="px-2 py-1">{user.name}</td>
                    <td className="px-2 py-1">{user.email}</td>
                    <td className="px-2 py-1 capitalize">{user.role}</td>
                    <td className="px-2 py-1">{user.tripsCompleted || 0}</td>
                    <td className="px-2 py-1">{user.bonusPaid ? "Yes" : "No"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
