
// notifications.js
import emailjs from 'emailjs-com';

export async function sendEmailNotification(toEmail, subject, data) {
  try {
    const templateParams = {
      to_email: toEmail,
      subject,
      user_name: data.name,
    };

    const result = await emailjs.send(
      'your_service_id',
      'your_template_id',
      templateParams,
      'your_user_id'
    );

    console.log('Email sent:', result.status, result.text);
  } catch (error) {
    console.error('Error sending email:', error);
  }
}
