export default function Driver() {
  return (
    <div className="p-4 text-center">
      <h1 className="text-2xl font-bold">Driver Page</h1>
    </div>
  );
}
