export default function Rider() {
  return (
    <div className="p-4 text-center">
      <h1 className="text-2xl font-bold">Rider Page</h1>
    </div>
  );
}
