export default function About() {
  return (
    <div className="p-4 text-center">
      <h1 className="text-2xl font-bold">About Page</h1>
    </div>
  );
}
