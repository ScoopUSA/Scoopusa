export default function HomePage() {
  return (
    <div className="p-4 text-center">
      <h1 className="text-2xl font-bold">HomePage Page</h1>
    </div>
  );
}
